<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Pelayanan Desa</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ganti dengan path stylesheet Anda -->
</head>
<body>
    
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="status.php">Status Pengajuan</a></li>
            <li><a href="notifikasi.php">Notifikasi</a></li>
            <!-- Tambahkan tautan ke halaman lain sesuai kebutuhan -->
        </ul>
        <ul>
            <li><a href="bantuan_panduan.php">Bantuan atau Panduan</a></li>
            <li><a href="about.php">Tentang Aplikasi</a></li>
        </ul>
    </nav>
    
    <main>
        
        <section>
            <center><img src="img/logo.png"></center>
        </section>
        
        <section>
            <p>
            	<center>Aplikasi Pelayanan Pengajuan Surat Online</center>
            </p>
        </section>
    </main>
    
    <footer>
        <p>Hak Cipta © 2023 Aplikasi Pelayanan Desa</p>
    </footer>
</body>
</html>
