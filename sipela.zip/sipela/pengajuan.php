<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Surat</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ganti dengan path stylesheet Anda -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
    
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="pengajuan.php">Pengajuan Surat</a></li>
            <li><a href="status.php">Status Pengajuan</a></li>
            <li><a href="notifikasi.php">Notifikasi</a></li>
            <!-- Tambahkan tautan ke halaman lain sesuai kebutuhan -->
        </ul>
        <ul>
            <li><a href="bantuan_panduan.php">Bantuan atau Panduan</a></li>
            <li><a href="about.php">Tentang Aplikasi</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <h2>Form Pengajuan Surat</h2>
            <form action="proses_pengajuan.php" method="POST">
                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required>
                
                <label for="nomor_telepon">Nomor Telepon:</label></br>
                <input type="tel" id="nomor_telepon" name="nomor_telepon" pattern="[0-9]{10,12}" required>
                <small>Contoh: 081234567890</small></br>

                <label for="jenis_surat">Jenis Surat:</label>
                <select id="jenis_surat" name="jenis_surat" required>
                    <option value="">-Pilih Surat-</option>
                    <option value="1">Surat Keterangan Usaha</option>
                    <option value="2">Surat Keterangan Kelahiran</option>
                    <option value="3">Surat Keterangan Kematian</option>
                    <option value="4">Surat Keterangan Tempat Usaha</option>
                    <option value="5">Surat Keterangan Domisili</option>
                    <option value="6">Surat Keterangan Tidak Mampu(Sekolah)</option>
                    <option value="7">Surat Keterangan Tidak Mampu(Umum)</option>
                    <option value="8">Surat Keterangan Miskin</option>
                    <option value="9">Surat Keterangan Penghasilan Orang Tua</option>
                    <option value="10">Surat Permohonan Izin Keramaian Pesta</option>
                    <option value="11">Surat Pengantar SKCK</option>
                    <option value="12">Surat Keterangan Ahli Waris</option>
                    <option value="13">Surat Keterangan Bepergian</option>
                    <option value="14">Surat Keterangan Tidak Berada di Tempat</option>
                    <option value="15">Surat Keterangan Beda Identitas</option>
                    <option value="16">Surat Pengantar Pindah</option>
                    <option value="17">Surat Keterangan Pindah</option>
                    <option value="18">Surat Pengantar Nikah</option>
                    <option value="19">Surat Keterangan Pernah Nikah</option>
                    <option value="20">Surat Keterangan Belum Pernah Nikah</option>
                    <option value="21">Surat Keterangan Duda/Janda</option>
                    <!-- Tambahkan pilihan jenis surat lainnya -->
                </select>
                
                <label for="keterangan">Keterangan:</label>
                <textarea id="keterangan" name="keterangan" rows="4" required></textarea>
                
                <button type="submit" class="btn btn-primary">Ajukan Surat</button>
            </form>
        </section>
    </main>
    
    <footer>
        <p>Hak Cipta © 2023 Aplikasi Pelayanan Desa</p>
    </footer>
</body>
</html>
