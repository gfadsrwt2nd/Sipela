<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ganti dengan path stylesheet Anda -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php"><i class="bi bi-house-door"></i> Beranda</a></li>
            <li><a href="pengajuan.php"><i class="bi bi-file-earmark-text"></i> Pengajuan Surat</a></li>
            <li><a href="status.php"><i class="bi bi-list"></i> Status Pengajuan</a></li>
            <li><a href="notifikasi.php"><i class="bi bi-bell"></i> Notifikasi</a></li>
            <!-- Tambahkan tautan ke halaman lain sesuai kebutuhan -->
        </ul>
        <ul>
            <li><a href="bantuan_panduan.php">Bantuan atau Panduan</a></li>
            <li><a href="about.php">Tentang Aplikasi</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <h2>Notifikasi</h2>
            <ul class="list-group">
                <?php
                // Kode koneksi ke database
                $host = "localhost";
                $username = "root";
                $password = "";
                $database = "pelayanan";

                $conn = new mysqli($host, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Koneksi gagal: " . $conn->connect_error);
                }

                // Query untuk mengambil data notifikasi
                $query = "SELECT * FROM notifikasi";
                $result = $conn->query($query);

                
                $conn->close();
                ?>
            </ul>
        </section>
    </main>
    
    <footer>
        <p>Hak Cipta © 2023 Aplikasi Pelayanan Desa</p>
    </footer>
</body>
</html>
