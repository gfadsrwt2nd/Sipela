<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bantuan dan Panduan</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ganti dengan path stylesheet Anda -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php"><i class="bi bi-house-door"></i> Beranda</a></li>
            <li><a href="pengajuan.php"><i class="bi bi-file-earmark-text"></i> Pengajuan Surat</a></li>
            <li><a href="status.php"><i class="bi bi-list"></i> Status Pengajuan</a></li>
            <li><a href="notifikasi.php"><i class="bi bi-bell"></i> Notifikasi</a></li>
            <!-- Tambahkan tautan ke halaman lain sesuai kebutuhan -->
        </ul>
        <ul>
            <li><a href="bantuan_panduan.php">Bantuan atau Panduan</a></li>
            <li><a href="about.php">Tentang Aplikasi</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <h2>Bantuan dan Panduan</h2>
            <p>Selamat datang di halaman Bantuan dan Panduan aplikasi pelayanan desa. Berikut adalah beberapa informasi yang dapat membantu Anda menggunakan aplikasi ini:</p>
            <ul>
                <li>Cara mengajukan surat: Pergi ke halaman Pengajuan Surat, isi formulir dengan benar, dan klik tombol "Ajukan Surat".</li>
                <li>Cek status pengajuan: Anda dapat melihat status pengajuan surat Anda di halaman Status Pengajuan.</li>
                <li>Notifikasi: Halaman Notifikasi akan menampilkan notifikasi terkait dengan pengajuan dan surat.</li>
                
                <!-- Tambahkan panduan lain sesuai kebutuhan -->
            </ul>
            <p>Jika Anda memerlukan bantuan lebih lanjut, silakan hubungi layanan pelanggan kami di nomor 08123456789 (WA), atau email support@desataraman.com.</p>
        </section>
    </main>
    
    <footer>
        <p>Hak Cipta © 2023 Aplikasi Pelayanan Desa</p>
    </footer>
</body>
</html>
