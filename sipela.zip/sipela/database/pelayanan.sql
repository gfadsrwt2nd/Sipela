-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Agu 2023 pada 07.48
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pelayanan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `aktivitas_pengguna`
--

CREATE TABLE `aktivitas_pengguna` (
  `ID_Aktivitas` int(11) NOT NULL,
  `ID_Pengguna` int(11) DEFAULT NULL,
  `Jenis_Aktivitas` varchar(255) DEFAULT NULL,
  `Tanggal_Aktivitas` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_surat`
--

CREATE TABLE `jenis_surat` (
  `ID_Jenis_Surat` int(11) NOT NULL,
  `Nama_Jenis_Surat` varchar(255) DEFAULT NULL,
  `Deskripsi_Jenis_Surat` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_surat`
--

INSERT INTO `jenis_surat` (`ID_Jenis_Surat`, `Nama_Jenis_Surat`, `Deskripsi_Jenis_Surat`) VALUES
(1, 'Surat Keterangan Usaha', 'Surat Keterangan Usaha'),
(2, 'Surat Keterangan Kelahiran', 'Surat Keterangan Kelahiran'),
(3, 'Surat Keterangan Kematian', 'Surat Keterangan Kematian'),
(4, 'Surat Keterangan Tempat Usaha', 'Surat Keterangan Tempat Usaha'),
(5, 'Surat Keterangan Domisili', 'Surat Keterangan Domisili'),
(6, 'Surat Keterangan Tidak Mampu(Sekolah)', 'Surat Keterangan Tidak Mampu(Sekolah)'),
(7, 'Surat Keterangan Tidak Mampu(Umum)', 'Surat Keterangan Tidak Mampu(Umum)'),
(8, 'Surat Keterangan Miskin', 'Surat Keterangan Miskin'),
(9, 'Surat Keterangan Penghasilan Orang Tua', 'Surat Keterangan Penghasilan Orang Tua'),
(10, 'Surat Permohonan Izin Keramaian Pesta', 'Surat Permohonan Izin Keramaian Pesta'),
(11, 'Surat Pengantar SKCK', 'Surat Pengantar SKCK'),
(12, 'Surat Keterangan Ahli Waris', 'Surat Keterangan Ahli Waris'),
(13, 'Surat Keterangan Bepergian', 'Surat Keterangan Bepergian'),
(14, 'Surat Keterangan Tidak Berada di Tempat', 'Surat Keterangan Tidak Berada di Tempat'),
(15, 'Surat Keterangan Beda Identitas', 'Surat Keterangan Beda Identitas'),
(16, 'Surat Pengantar Pindah', 'Surat Pengantar Pindah'),
(17, 'Surat Keterangan Pindah', 'Surat Keterangan Pindah'),
(18, 'Surat Pengantar Nikah', 'Surat Pengantar Nikah'),
(19, 'Surat Keterangan Pernah Nikah', 'Surat Keterangan Pernah Nikah'),
(20, 'Surat Keterangan Belum Pernah Nikah', 'Surat Keterangan Belum Pernah Nikah'),
(21, 'Surat Keterangan Duda/Janda', 'Surat Keterangan Duda/Janda');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_penggunaan`
--

CREATE TABLE `log_penggunaan` (
  `ID_Log` int(11) NOT NULL,
  `ID_Pengajuan` int(11) DEFAULT NULL,
  `Tanggal_Akses` datetime DEFAULT NULL,
  `Aktivitas` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuan_surat`
--

CREATE TABLE `pengajuan_surat` (
  `ID_Pengajuan` int(11) NOT NULL,
  `jenis_surat` varchar(100) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `nomor_telepon` varchar(100) DEFAULT NULL,
  `keterangan` text,
  `tanggal_pengajuan` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Menunggu','Disetujui','Ditolak') NOT NULL,
  `Tanggal_Persetujuan` datetime DEFAULT NULL,
  `Catatan_Persetujuan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengajuan_surat`
--

INSERT INTO `pengajuan_surat` (`ID_Pengajuan`, `jenis_surat`, `nama`, `nomor_telepon`, `keterangan`, `tanggal_pengajuan`, `status`, `Tanggal_Persetujuan`, `Catatan_Persetujuan`) VALUES
(1, '16', 'Rusdi', '081233215678', 'Ingin merantau', '2023-08-09 21:18:20', 'Menunggu', NULL, NULL),
(2, '1', 'Intan', '08123456789', 'Untuk membuka usaha sendiri ', '2023-08-09 21:18:48', 'Menunggu', NULL, NULL),
(3, '5', 'Antoni', '085612388283', 'untuk melamar pekerjaan', '2023-08-09 21:19:18', 'Menunggu', NULL, NULL),
(4, '11', 'Nabila', '081233210127', 'mau membuat skck', '2023-08-09 21:20:12', 'Menunggu', NULL, NULL),
(5, '15', 'Genta', '083216293411', 'Wibu akut wkwk', '2023-08-09 21:21:22', 'Menunggu', NULL, NULL),
(6, '9', 'Vino', '087718923991', 'untuk pendaftaran beasiswa kuliah', '2023-08-09 21:23:19', 'Menunggu', NULL, NULL),
(7, '10', 'Elvina', '082356643400', 'ingin mengadakan acara', '2023-08-09 21:24:47', 'Menunggu', NULL, NULL),
(8, '19', 'Andrianto', '081234407288', 'untuk pengajuan bonus di kerjaan', '2023-08-09 21:26:08', 'Menunggu', NULL, NULL),
(12, '2', '\' OR \'1\'=\'1', '0812345666', '\'', '2023-08-09 21:51:16', 'Menunggu', NULL, NULL),
(14, '6', '\'\'\'asdas', '08123456789', '\'', '2023-08-09 21:52:42', 'Menunggu', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `ID_Pengguna` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `Hak_Akses` enum('Administrator','User') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `aktivitas_pengguna`
--
ALTER TABLE `aktivitas_pengguna`
  ADD PRIMARY KEY (`ID_Aktivitas`),
  ADD KEY `ID_Pengguna` (`ID_Pengguna`);

--
-- Indeks untuk tabel `jenis_surat`
--
ALTER TABLE `jenis_surat`
  ADD PRIMARY KEY (`ID_Jenis_Surat`);

--
-- Indeks untuk tabel `log_penggunaan`
--
ALTER TABLE `log_penggunaan`
  ADD PRIMARY KEY (`ID_Log`),
  ADD KEY `ID_Pengajuan` (`ID_Pengajuan`);

--
-- Indeks untuk tabel `pengajuan_surat`
--
ALTER TABLE `pengajuan_surat`
  ADD PRIMARY KEY (`ID_Pengajuan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`ID_Pengguna`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `aktivitas_pengguna`
--
ALTER TABLE `aktivitas_pengguna`
  MODIFY `ID_Aktivitas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jenis_surat`
--
ALTER TABLE `jenis_surat`
  MODIFY `ID_Jenis_Surat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `log_penggunaan`
--
ALTER TABLE `log_penggunaan`
  MODIFY `ID_Log` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pengajuan_surat`
--
ALTER TABLE `pengajuan_surat`
  MODIFY `ID_Pengajuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `ID_Pengguna` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `aktivitas_pengguna`
--
ALTER TABLE `aktivitas_pengguna`
  ADD CONSTRAINT `aktivitas_pengguna_ibfk_1` FOREIGN KEY (`ID_Pengguna`) REFERENCES `pengguna` (`ID_Pengguna`);

--
-- Ketidakleluasaan untuk tabel `log_penggunaan`
--
ALTER TABLE `log_penggunaan`
  ADD CONSTRAINT `log_penggunaan_ibfk_1` FOREIGN KEY (`ID_Pengajuan`) REFERENCES `pengajuan_surat` (`ID_Pengajuan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
