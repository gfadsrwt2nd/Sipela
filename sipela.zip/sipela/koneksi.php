<?php
$host = "localhost"; // Nama host database
$username = "root"; // Username database
$password = ""; // Password database
$database = "pelayanan"; // Nama database

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Jika koneksi berhasil, Anda dapat melakukan operasi database di sini

// Tutup koneksi setelah selesai
$conn->close();
?>
