<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $nomor_telepon = $_POST['nomor_telepon'];
    $jenis_surat = $_POST["jenis_surat"];
    $keterangan = $_POST["keterangan"];

    // Lakukan validasi data jika diperlukan
    // ...

    // Simpan data pengajuan ke database atau file, sesuai dengan metode yang Anda gunakan
    // Contoh menggunakan metode koneksi MySQLi
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "pelayanan";

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO pengajuan_surat (nama, nomor_telepon, jenis_surat, keterangan) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nama, $nomor_telepon, $jenis_surat, $keterangan);

    if ($stmt->execute()) {
    // Berhasil menyimpan data
    echo "Data pengajuan surat berhasil disimpan.";
    } else {
        // Gagal menyimpan data
        echo "Terjadi kesalahan saat menyimpan data.";
    }

    $stmt->close();

    $conn->close();
}
?>
