<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Aplikasi</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Ganti dengan path stylesheet Anda -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php"><i class="bi bi-house-door"></i> Beranda</a></li>
            <li><a href="pengajuan.php"><i class="bi bi-file-earmark-text"></i> Pengajuan Surat</a></li>
            <li><a href="status.php"><i class="bi bi-list"></i> Status Pengajuan</a></li>
            <li><a href="notifikasi.php"><i class="bi bi-bell"></i> Notifikasi</a></li>
            <!-- Tambahkan tautan ke halaman lain sesuai kebutuhan -->
        </ul>
        <ul>
            <li><a href="bantuan_panduan.php">Bantuan atau Panduan</a></li>
            <li><a href="about.php">Tentang Aplikasi</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <center><img src="img/logo.png"></center></br>
            <h2>Tentang Aplikasi</h2>
            <p>Aplikasi Pelayanan Desa adalah sebuah aplikasi yang dibuat untuk mempermudah penduduk desa dalam mengajukan surat keterangan secara online. Aplikasi ini membantu mengurangi proses manual dan kertas dalam pengajuan surat serta memberikan transparansi terkait status pengajuan.</p>
            <p>Aplikasi ini dikembangkan oleh [Nama Perusahaan/Individu] dan didukung oleh teknologi modern untuk memberikan pengalaman pengguna yang nyaman dan efisien. Kami berkomitmen untuk terus meningkatkan fitur-fitur yang ada agar dapat memenuhi kebutuhan masyarakat desa secara lebih baik.</p>
            <p>Untuk pertanyaan lebih lanjut atau umpan balik, Anda dapat menghubungi kami di [support@desataraman.com] atau nomor telepon 08123456789 .</p>
        </section>
    </main>
    
    <footer>
        <p>Hak Cipta © 2023 Aplikasi Pelayanan Desa</p>
    </footer>
</body>
</html>
